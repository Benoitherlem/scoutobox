(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["evaluation-evaluation-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/evaluation/evaluation.page.html":
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/evaluation/evaluation.page.html ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-buttons slot=\"end\">\n      <ion-back-button text=\"Retour\"  defaultHref=\"home\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Evaluer une activité</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n\n<ion-content class=\"card-background-page\" class=\"ion-padding\" >\n\n\n\n<div  *ngIf=\"item=='EVAL'\">\n\n  <div class=\"ion-text-center\" class=\"marge\"> <ion-button round (click)=\"raz_eval(eval_coche)\" >Nouvelle évaluation</ion-button></div>\n\n  <div *ngFor=\"let p of data; let i = index\"  class=\"ion-text-right\">\n\n      <div  *ngIf=\"p.type=='separation'\">\n        <ion-card class=\"card-background-page\">\n          <img src={{p.img}} />\n            <div class=\"card-title\"> {{p.categorie}}</div>\n         </ion-card>\n      </div>\n\n      <div  *ngIf=\"p.type=='range'\">\n            <ion-item-divider class=\"ion-text-left\"><b>{{p.eval}}</b>  </ion-item-divider>\n            <br>\n\n            <ion-item  *ngIf=\"eval_coche[i]==val1\" no-lines><ion-avatar slot=\"end\"><img src=\"assets/imgs/evaluation/tresmal.png\"></ion-avatar><i><small>{{p.res1}}</small></i></ion-item>\n            <ion-item  *ngIf=\"eval_coche[i]==val2\" no-lines><ion-avatar slot=\"end\"><img src=\"assets/imgs/evaluation/mal.png\"></ion-avatar><i><small>{{p.res2}}</small></i></ion-item>\n            <ion-item  *ngIf=\"eval_coche[i]==val3\" no-lines><ion-avatar slot=\"end\"><img src=\"assets/imgs/evaluation/bien.png\"></ion-avatar><i><small>{{p.res3}}</small></i></ion-item>\n            <ion-item  *ngIf=\"eval_coche[i]==val4\" no-lines><ion-avatar slot=\"end\"><img src=\"assets/imgs/evaluation/tresbien.png\"></ion-avatar><i><small>{{p.res4}}</small></i></ion-item>\n\n            <ion-range min=\"1\" max=\"4\" snaps=\"true\" step = \"1\" [(ngModel)]=eval_coche[i] color=\"secondary\">\n              <ion-icon range-left small name={{p.icone_range_min}}></ion-icon>\n              <ion-icon range-right name={{p.icone_range_max}}></ion-icon>\n              </ion-range>\n\n        </div>\n\n      <div *ngIf=\"p.type=='toggle'\">\n      <ion-item>\n      <ion-label><small class=\"ion-text-wrap\">{{p.eval}}</small></ion-label> <ion-toggle color=\"secondary\" [(ngModel)]=eval_coche[i]></ion-toggle>\n      </ion-item>\n\n        </div>\n\n\n  </div>\n</div>\n\n<div  *ngIf=\"item=='RESULTAT'\">\n    <div><ion-card class=\"card-background-page\">\n      <img src=\"assets/imgs/evaluation/evaluation_flat.png\" />\n        <div class=\"card-title\"> Résultat</div>\n     </ion-card></div>\n\n     <div><small><i>Les activités ne sont pas sensées atteindre 100%, c'est d'ailleurs rarement possible.<br>Cet outil te permet d'identifier des axes de progrès pour la prochaine activité.</i></small></div>\n\n     <br><br>\n\n   </div>\n  <canvas id=\"myChart\"> </canvas>\n\n<div  *ngIf=\"item=='RESULTAT'\">\n\n   <div class = \"marge\">\n   <br><b>Cadre:</b> {{radarChartData[0].data[0]}} %\n   <br><b>Règles:</b> {{radarChartData[0].data[1]}} %\n   <br><b>Equipe:</b> {{radarChartData[0].data[2]}} %\n   <br><b>Imaginaire:</b> {{radarChartData[0].data[3]}} %\n   <br><b>Roles:</b> {{radarChartData[0].data[4]}} %\n   <br><b>Action:</b> {{radarChartData[0].data[5]}} %\n   <br><b>Sens:</b> {{radarChartData[0].data[6]}} %<br><br>\n\n\n\n   </div>\n\n</div>\n\n\n  <div *ngIf=\"item=='EVAL'\" class=\"ion-text-center\" class=\"marge\"> <ion-button  router-direction=\"forward\" round (click)=\"openresultat('RESULTAT',eval_coche)\" >Résultat</ion-button></div>\n  <div *ngIf=\"item=='RESULTAT'\" class=\"ion-text-center\" class=\"marge\"> <ion-button  router-direction=\"back\" round (click)=\"openresultat('EVAL',eval_coche)\" >Retour à l'évaluation</ion-button></div>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/evaluation/evaluation-routing.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/evaluation/evaluation-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: EvaluationPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EvaluationPageRoutingModule", function() { return EvaluationPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _evaluation_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./evaluation.page */ "./src/app/evaluation/evaluation.page.ts");




var routes = [
    {
        path: '',
        component: _evaluation_page__WEBPACK_IMPORTED_MODULE_3__["EvaluationPage"]
    }
];
var EvaluationPageRoutingModule = /** @class */ (function () {
    function EvaluationPageRoutingModule() {
    }
    EvaluationPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], EvaluationPageRoutingModule);
    return EvaluationPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/evaluation/evaluation.module.ts":
/*!*************************************************!*\
  !*** ./src/app/evaluation/evaluation.module.ts ***!
  \*************************************************/
/*! exports provided: EvaluationPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EvaluationPageModule", function() { return EvaluationPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _evaluation_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./evaluation-routing.module */ "./src/app/evaluation/evaluation-routing.module.ts");
/* harmony import */ var _evaluation_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./evaluation.page */ "./src/app/evaluation/evaluation.page.ts");







var EvaluationPageModule = /** @class */ (function () {
    function EvaluationPageModule() {
    }
    EvaluationPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _evaluation_routing_module__WEBPACK_IMPORTED_MODULE_5__["EvaluationPageRoutingModule"]
            ],
            declarations: [_evaluation_page__WEBPACK_IMPORTED_MODULE_6__["EvaluationPage"]]
        })
    ], EvaluationPageModule);
    return EvaluationPageModule;
}());



/***/ }),

/***/ "./src/app/evaluation/evaluation.page.scss":
/*!*************************************************!*\
  !*** ./src/app/evaluation/evaluation.page.scss ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".card-background-page ion-card {\n  position: relative;\n}\n.card-background-page .card-title {\n  position: absolute;\n  top: 30%;\n  font-size: 2em;\n  width: 100%;\n  font-weight: bold;\n  color: #fff;\n  text-align: center;\n}\n.card-background-page .card-subtitle {\n  font-size: 1em;\n  position: absolute;\n  top: 10%;\n  width: 100%;\n  color: #000;\n  text-align: center;\n}\n.card-background-page .marge {\n  margin-left: 2em;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZXZhbHVhdGlvbi9DOlxcVXNlcnNcXFVTRVJcXHNjb3V0b2JveC9zcmNcXGFwcFxcZXZhbHVhdGlvblxcZXZhbHVhdGlvbi5wYWdlLnNjc3MiLCJzcmMvYXBwL2V2YWx1YXRpb24vZXZhbHVhdGlvbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUU7RUFDRSxrQkFBQTtBQ0RKO0FETUU7RUFDRSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxjQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0VBQ0EsV0FBQTtFQUNFLGtCQUFBO0FDSk47QURPRTtFQUVFLGNBQUE7RUFDQSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxXQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0FDTko7QURTRTtFQUNBLGdCQUFBO0FDUEYiLCJmaWxlIjoic3JjL2FwcC9ldmFsdWF0aW9uL2V2YWx1YXRpb24ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNhcmQtYmFja2dyb3VuZC1wYWdlIHtcclxuXHJcbiAgaW9uLWNhcmQge1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIC8vICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG5cclxuICB9XHJcblxyXG4gIC5jYXJkLXRpdGxlIHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogMzAlO1xyXG4gICAgZm9udC1zaXplOiAyLjBlbTtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIH1cclxuXHJcbiAgLmNhcmQtc3VidGl0bGUge1xyXG5cclxuICAgIGZvbnQtc2l6ZTogMS4wZW07XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDEwJTtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgY29sb3I6ICMwMDA7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgfVxyXG5cclxuICAubWFyZ2Uge1xyXG4gIG1hcmdpbi1sZWZ0OiAyZW07XHJcbiAgfVxyXG5cclxuXHJcbn1cclxuIiwiLmNhcmQtYmFja2dyb3VuZC1wYWdlIGlvbi1jYXJkIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuLmNhcmQtYmFja2dyb3VuZC1wYWdlIC5jYXJkLXRpdGxlIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDMwJTtcbiAgZm9udC1zaXplOiAyZW07XG4gIHdpZHRoOiAxMDAlO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgY29sb3I6ICNmZmY7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbi5jYXJkLWJhY2tncm91bmQtcGFnZSAuY2FyZC1zdWJ0aXRsZSB7XG4gIGZvbnQtc2l6ZTogMWVtO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMTAlO1xuICB3aWR0aDogMTAwJTtcbiAgY29sb3I6ICMwMDA7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbi5jYXJkLWJhY2tncm91bmQtcGFnZSAubWFyZ2Uge1xuICBtYXJnaW4tbGVmdDogMmVtO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/evaluation/evaluation.page.ts":
/*!***********************************************!*\
  !*** ./src/app/evaluation/evaluation.page.ts ***!
  \***********************************************/
/*! exports provided: EvaluationPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EvaluationPage", function() { return EvaluationPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
/* harmony import */ var chart_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! chart.js */ "./node_modules/chart.js/dist/Chart.js");
/* harmony import */ var chart_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(chart_js__WEBPACK_IMPORTED_MODULE_6__);








var EvaluationPage = /** @class */ (function () {
    function EvaluationPage(router, http, storage, navCtrl, alertController) {
        var _this = this;
        this.router = router;
        this.http = http;
        this.storage = storage;
        this.navCtrl = navCtrl;
        this.alertController = alertController;
        // Radar
        this.radarChartLabels = ['CADRE', 'REGLES', 'EQUIPE', 'IMAGINAIRE', 'ROLES', 'ACTION', 'SENS'];
        this.radarChartData = [{ data: [0, 0, 0, 0, 0, 0, 0], label: "Evaluation" }, { data: [0, 0, 0, 0, 0, 0, 0], label: "Ref" }];
        this.radarChartType = 'radar';
        this.barChartColors = [{ backgroundColor: 'rgba(44, 205, 0, 1)', borderColor: "rgba(36,142,7,1)", borderWidth: 2 },
            { backgroundColor: 'rgba(221, 255, 218, 0)', borderColor: "rgba(255,255,255,0)", borderWidth: 0 }];
        this.chartOptions = {
            scale: { ticks: { beginAtZero: true, min: 0, max: 100, stepSize: 20 }, pointLabels: { fontSize: 14 } },
            legend: { display: false, }, tooltips: { callbacks: { label: function (tooltipItem) { return tooltipItem.yLabel + ": " + tooltipItem.xLabel; }, title: function () { return null; }, } }
        };
        this.data = "";
        this.filecontent = "";
        this.eval_coche = [];
        this.val1 = 1;
        this.val2 = 2;
        this.val3 = 3;
        this.val4 = 4;
        this.i = "0";
        this.eval = "eval";
        this.item = "EVAL";
        this.display = "none";
        this.w = 400;
        this.h = 400;
        this.myLineChart = [];
        this.title = 'angular8chartjs';
        this.http.get("assets/data/data_evaluation.json", { responseType: 'json' }).subscribe(function (fileContent) { console.log(fileContent); _this.data = fileContent["evaluation"]; });
    }
    EvaluationPage.prototype.ngOnInit = function () {
        this.canvas = document.getElementById('myChart');
        this.canvas.style.display = "none ";
    };
    EvaluationPage.prototype.openresultat = function (item, eval_coche) {
        this.item = item;
        this.radarChartData[0].data[0] = 0;
        this.radarChartData[0].data[1] = 0;
        this.radarChartData[0].data[2] = 0;
        this.radarChartData[0].data[3] = 0;
        this.radarChartData[0].data[4] = 0;
        this.radarChartData[0].data[5] = 0;
        this.radarChartData[0].data[6] = 0;
        this.radarChartData[1].data[0] = 0;
        this.radarChartData[1].data[1] = 0;
        this.radarChartData[1].data[2] = 0;
        this.radarChartData[1].data[3] = 0;
        this.radarChartData[1].data[4] = 0;
        this.radarChartData[1].data[5] = 0;
        this.radarChartData[1].data[6] = 0;
        for (var _i = 0; _i < this.data.length; _i++) {
            // var item:"";
            var item_1 = {};
            item_1 = this.data[_i];
            //  var item = this.data[_i];
            var categ = 0;
            if (item_1.categorie == this.radarChartLabels[0]) {
                categ = 0;
            }
            if (item_1.categorie == this.radarChartLabels[1]) {
                categ = 1;
            }
            if (item_1.categorie == this.radarChartLabels[2]) {
                categ = 2;
            }
            if (item_1.categorie == this.radarChartLabels[3]) {
                categ = 3;
            }
            if (item_1.categorie == this.radarChartLabels[4]) {
                categ = 4;
            }
            if (item_1.categorie == this.radarChartLabels[5]) {
                categ = 5;
            }
            if (item_1.categorie == this.radarChartLabels[6]) {
                categ = 6;
            }
            if (item_1.type == 'range') {
                this.radarChartData[1].data[categ] = this.radarChartData[1].data[categ] + 4;
                if (this.eval_coche[_i] != null) {
                    this.radarChartData[0].data[categ] = this.radarChartData[0].data[categ] + this.eval_coche[_i];
                }
            }
            if (item_1.type == 'toggle') {
                this.radarChartData[1].data[categ] = this.radarChartData[1].data[categ] + 4;
                if (this.eval_coche[_i] != null) {
                    if (this.eval_coche[_i] == true) {
                        this.radarChartData[0].data[categ] = this.radarChartData[0].data[categ] + 4;
                    }
                }
            }
        }
        this.radarChartData[0].data[0] = Math.round(this.radarChartData[0].data[0] * 100 / this.radarChartData[1].data[0]);
        this.radarChartData[0].data[1] = Math.round(this.radarChartData[0].data[1] * 100 / this.radarChartData[1].data[1]);
        this.radarChartData[0].data[2] = Math.round(this.radarChartData[0].data[2] * 100 / this.radarChartData[1].data[2]);
        this.radarChartData[0].data[3] = Math.round(this.radarChartData[0].data[3] * 100 / this.radarChartData[1].data[3]);
        this.radarChartData[0].data[4] = Math.round(this.radarChartData[0].data[4] * 100 / this.radarChartData[1].data[4]);
        this.radarChartData[0].data[5] = Math.round(this.radarChartData[0].data[5] * 100 / this.radarChartData[1].data[5]);
        this.radarChartData[0].data[6] = Math.round(this.radarChartData[0].data[6] * 100 / this.radarChartData[1].data[6]);
        this.radarChartData[1].data[0] = this.radarChartData[1].data[0] * 100 / this.radarChartData[1].data[0];
        this.radarChartData[1].data[1] = this.radarChartData[1].data[1] * 100 / this.radarChartData[1].data[1];
        this.radarChartData[1].data[2] = this.radarChartData[1].data[2] * 100 / this.radarChartData[1].data[2];
        this.radarChartData[1].data[3] = this.radarChartData[1].data[3] * 100 / this.radarChartData[1].data[3];
        this.radarChartData[1].data[4] = this.radarChartData[1].data[4] * 100 / this.radarChartData[1].data[4];
        this.radarChartData[1].data[5] = this.radarChartData[1].data[5] * 100 / this.radarChartData[1].data[5];
        this.radarChartData[1].data[6] = this.radarChartData[1].data[6] * 100 / this.radarChartData[1].data[6];
        this.canvas = document.getElementById('myChart');
        this.ctx = this.canvas.getContext('2d');
        var myChart = new chart_js__WEBPACK_IMPORTED_MODULE_6__(this.ctx, {
            type: 'radar',
            data: {
                labels: ['CADRE', 'REGLES', 'EQUIPE', 'IMAGINAIRE', 'ROLES', 'ACTION', 'SENS'],
                datasets: [{ label: 'My First dataset',
                        data: [this.radarChartData[0].data[0],
                            this.radarChartData[0].data[1],
                            this.radarChartData[0].data[2],
                            this.radarChartData[0].data[3],
                            this.radarChartData[0].data[4],
                            this.radarChartData[0].data[5],
                            this.radarChartData[0].data[6]],
                        backgroundColor: 'rgba(44, 205, 0, 1)', borderColor: "rgba(36,142,7,1)", borderWidth: 2
                    }, { label: 'My 2nd dataset',
                        data: [this.radarChartData[1].data[0],
                            this.radarChartData[1].data[1],
                            this.radarChartData[1].data[2],
                            this.radarChartData[1].data[3],
                            this.radarChartData[1].data[4],
                            this.radarChartData[1].data[5],
                            this.radarChartData[1].data[6]],
                        backgroundColor: 'rgba(221, 255, 218, 0)', borderColor: "rgba(255,255,255,0)", borderWidth: 0
                    }]
            },
            options: { responsive: true,
                scale: { ticks: { beginAtZero: true, min: 0, max: 100, stepSize: 20 }, pointLabels: { fontSize: 14 } },
                legend: { display: false, }, tooltips: { callbacks: { label: function (tooltipItem) { return tooltipItem.yLabel + ": " + tooltipItem.xLabel; }, title: function () { return null; }, } }
            }
        });
        if (this.item == "RESULTAT") {
            this.display = "block";
        }
        if (this.item != "RESULTAT") {
            this.display = "none";
        }
        this.canvas.style.display = this.display;
    };
    EvaluationPage.prototype.raz_eval = function (eval_coche) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var raz_coche, alert;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        raz_coche = [];
                        return [4 /*yield*/, this.alertController.create({
                                header: 'Effacer tout!',
                                message: 'Souhaitez démarrer une nouvelle évaluation ?',
                                buttons: [
                                    {
                                        text: 'Cancel',
                                        role: 'cancel',
                                        cssClass: 'secondary',
                                        handler: function () {
                                            ;
                                        }
                                    }, {
                                        text: 'Effacer',
                                        handler: function () {
                                            _this.eval_coche = raz_coche;
                                            _this.storage.set('eval_coche', raz_coche);
                                            _this.item = 'EVAL';
                                            _this.router.navigate(['/evaluation']);
                                        }
                                    }
                                ]
                            })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        ;
                        return [2 /*return*/];
                }
            });
        });
    };
    EvaluationPage.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] },
        { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] }
    ]; };
    EvaluationPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-evaluation',
            template: __webpack_require__(/*! raw-loader!./evaluation.page.html */ "./node_modules/raw-loader/index.js!./src/app/evaluation/evaluation.page.html"),
            styles: [__webpack_require__(/*! ./evaluation.page.scss */ "./src/app/evaluation/evaluation.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"],
            _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]])
    ], EvaluationPage);
    return EvaluationPage;
}());



/***/ })

}]);
//# sourceMappingURL=evaluation-evaluation-module-es5.js.map