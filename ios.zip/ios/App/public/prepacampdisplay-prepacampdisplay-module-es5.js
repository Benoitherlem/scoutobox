(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["prepacampdisplay-prepacampdisplay-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/prepacamp/prepacampdisplay/prepacampdisplay.page.html":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/prepacamp/prepacampdisplay/prepacampdisplay.page.html ***!
  \*************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-buttons slot=\"end\"><ion-back-button text=\"Retour\"  defaultHref=\"home\"></ion-back-button></ion-buttons>\n    <ion-title>Préparer un camp</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n\n\n\n<h1>  <b>{{name}}</b></h1>\n<ion-card color=\"light\" >\n\n<div class=\"marge\">\n  <b><small><span text-wrap [innerHTML]=\"titre\"></span></small></b><br>\n  <i><small><span text-wrap [innerHTML]=\"extrait\"></span></small></i>\n </div></ion-card><br>\n\n<small><span text-wrap [innerHTML]=\"contenu\"></span></small>\n\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/prepacamp/prepacampdisplay/prepacampdisplay-routing.module.ts":
/*!*******************************************************************************!*\
  !*** ./src/app/prepacamp/prepacampdisplay/prepacampdisplay-routing.module.ts ***!
  \*******************************************************************************/
/*! exports provided: PrepacampdisplayPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PrepacampdisplayPageRoutingModule", function() { return PrepacampdisplayPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _prepacampdisplay_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./prepacampdisplay.page */ "./src/app/prepacamp/prepacampdisplay/prepacampdisplay.page.ts");




var routes = [
    {
        path: '',
        component: _prepacampdisplay_page__WEBPACK_IMPORTED_MODULE_3__["PrepacampdisplayPage"]
    }
];
var PrepacampdisplayPageRoutingModule = /** @class */ (function () {
    function PrepacampdisplayPageRoutingModule() {
    }
    PrepacampdisplayPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], PrepacampdisplayPageRoutingModule);
    return PrepacampdisplayPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/prepacamp/prepacampdisplay/prepacampdisplay.module.ts":
/*!***********************************************************************!*\
  !*** ./src/app/prepacamp/prepacampdisplay/prepacampdisplay.module.ts ***!
  \***********************************************************************/
/*! exports provided: PrepacampdisplayPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PrepacampdisplayPageModule", function() { return PrepacampdisplayPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _prepacampdisplay_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./prepacampdisplay-routing.module */ "./src/app/prepacamp/prepacampdisplay/prepacampdisplay-routing.module.ts");
/* harmony import */ var _prepacampdisplay_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./prepacampdisplay.page */ "./src/app/prepacamp/prepacampdisplay/prepacampdisplay.page.ts");







var PrepacampdisplayPageModule = /** @class */ (function () {
    function PrepacampdisplayPageModule() {
    }
    PrepacampdisplayPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _prepacampdisplay_routing_module__WEBPACK_IMPORTED_MODULE_5__["PrepacampdisplayPageRoutingModule"]
            ],
            declarations: [_prepacampdisplay_page__WEBPACK_IMPORTED_MODULE_6__["PrepacampdisplayPage"]]
        })
    ], PrepacampdisplayPageModule);
    return PrepacampdisplayPageModule;
}());



/***/ }),

/***/ "./src/app/prepacamp/prepacampdisplay/prepacampdisplay.page.scss":
/*!***********************************************************************!*\
  !*** ./src/app/prepacamp/prepacampdisplay/prepacampdisplay.page.scss ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".marge {\n  margin-left: 2em;\n  margin-right: 2em;\n  margin-bottom: 2em;\n  margin-top: 2em;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHJlcGFjYW1wL3ByZXBhY2FtcGRpc3BsYXkvQzpcXFVzZXJzXFxVU0VSXFxzY291dG9ib3gvc3JjXFxhcHBcXHByZXBhY2FtcFxccHJlcGFjYW1wZGlzcGxheVxccHJlcGFjYW1wZGlzcGxheS5wYWdlLnNjc3MiLCJzcmMvYXBwL3ByZXBhY2FtcC9wcmVwYWNhbXBkaXNwbGF5L3ByZXBhY2FtcGRpc3BsYXkucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQ0NBIiwiZmlsZSI6InNyYy9hcHAvcHJlcGFjYW1wL3ByZXBhY2FtcGRpc3BsYXkvcHJlcGFjYW1wZGlzcGxheS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubWFyZ2Uge1xyXG5tYXJnaW4tbGVmdDogMmVtO1xyXG5tYXJnaW4tcmlnaHQ6IDJlbTtcclxubWFyZ2luLWJvdHRvbTogMmVtO1xyXG5tYXJnaW4tdG9wOiAyZW07XHJcbn1cclxuIiwiLm1hcmdlIHtcbiAgbWFyZ2luLWxlZnQ6IDJlbTtcbiAgbWFyZ2luLXJpZ2h0OiAyZW07XG4gIG1hcmdpbi1ib3R0b206IDJlbTtcbiAgbWFyZ2luLXRvcDogMmVtO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/prepacamp/prepacampdisplay/prepacampdisplay.page.ts":
/*!*********************************************************************!*\
  !*** ./src/app/prepacamp/prepacampdisplay/prepacampdisplay.page.ts ***!
  \*********************************************************************/
/*! exports provided: PrepacampdisplayPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PrepacampdisplayPage", function() { return PrepacampdisplayPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");





var PrepacampdisplayPage = /** @class */ (function () {
    function PrepacampdisplayPage(route, router, http) {
        this.route = route;
        this.router = router;
        this.http = http;
    }
    PrepacampdisplayPage.prototype.ngOnInit = function () {
        this.id = this.route.snapshot.paramMap.get('id');
        this.name = this.route.snapshot.paramMap.get('name');
        this.titre = this.route.snapshot.paramMap.get('titre');
        this.extrait = this.route.snapshot.paramMap.get('extrait');
        this.type = this.route.snapshot.paramMap.get('type');
        this.contenu = this.route.snapshot.paramMap.get('contenu');
        //this.http.get("assets/data/data_prepacamp.json", {responseType: 'json'}).subscribe(fileContent => { this.item = fileContent["prepacamp"][this.id];});
        //this.http.get("assets/data/data_prepacamp.json", {responseType: 'json'}).subscribe(fileContent => { this.data_prepacamp = fileContent["prepacamp"];});
    };
    PrepacampdisplayPage.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
    ]; };
    PrepacampdisplayPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-prepacampdisplay',
            template: __webpack_require__(/*! raw-loader!./prepacampdisplay.page.html */ "./node_modules/raw-loader/index.js!./src/app/prepacamp/prepacampdisplay/prepacampdisplay.page.html"),
            styles: [__webpack_require__(/*! ./prepacampdisplay.page.scss */ "./src/app/prepacamp/prepacampdisplay/prepacampdisplay.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], PrepacampdisplayPage);
    return PrepacampdisplayPage;
}());



/***/ })

}]);
//# sourceMappingURL=prepacampdisplay-prepacampdisplay-module-es5.js.map