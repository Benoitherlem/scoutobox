(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["qualification-qualification-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/qualification/qualification.page.html":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/qualification/qualification.page.html ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-buttons slot=\"end\">\n      <ion-back-button text=\"Retour\"  defaultHref=\"home\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Qualifications</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n\n<ion-content padding>\n<small>Les éléments indiqués si dessous sont calculés à partir du guide réglementaire du Scoutisme Français 2018. La déclaration d'un accueil de scoutisme nécessite la prise en compte d'autres facteurs qui ne peuvent être objectivés dans une application: compétences montrées, fonctionnement de la maitrise, expériences... </small>\n<br><br>\n<ion-list>\n\n\n  <ion-item color='medium'><ion-label> Calculer des qualifications requises</ion-label></ion-item>\n  <ion-item>\n  <ion-label><span text-wrap><small>La durée du séjour est supérieure ou égale à 4 nuits</small></span></ion-label> <ion-toggle color=\"secondary\" [(ngModel)]=nuits></ion-toggle>\n  </ion-item>\n\n  <ion-item>\n      <ion-label><small>Tranche d'age</small></ion-label>\n      <ion-select placeholder=\"Sélectionner la tranche d'age\" [(ngModel)]= trancheage>\n        <ion-select-option value=\"1\">6-8 ans</ion-select-option>\n        <ion-select-option value=\"2\">8-11 ans</ion-select-option>\n        <ion-select-option value=\"3\">11-14 ans</ion-select-option>\n        <ion-select-option value=\"4\">14-17 ans</ion-select-option>\n\n      </ion-select>\n    </ion-item>\n\n    <ion-item><small> Nombre de jeunes:  {{nbjeunes}} &nbsp;&nbsp; <i> curseur ci dessous</i> </small></ion-item>\n    <ion-item>\n          <ion-range min=\"0\" max=\"40\" step=\"1\" snaps=\"true\" pin=true [(ngModel)]= nbjeunes color=\"secondary\">\n            <ion-icon slot=\"start\" name=\"body\"></ion-icon>\n            <ion-icon slot=\"end\" name=\"body\"></ion-icon>\n          </ion-range>\n  </ion-item>\n\n\n  <ion-item color ='secondary' *ngIf='nbjeunes'>\n    <div *ngIf=\"(nuits!=true)||(nbjeunes<7)\"><br> Les séjour d'accueil de scoutisme de moins de 7 jeunes ou d'une durée de moins de 4 nuits ne nécessitent pas de déclaration spécifique, la déclaration d'accueil de scoutisme de l'année est suffisante.\n    <br><br> Il est nécessaire de vérifier que la déclaration d'accueil de scoutisme de l'année couvre bien la période du séjour (en particulier pour les séjours de juillet-aout)<br><br></div>\n    <div *ngIf=\"(nuits==true)&&(nbjeunes>7)\">\n\n\n    <br><br>\n    <div *ngIf=\"(trancheage==4)\"> <b>Tous les jeunes</b> ont plus de 14 ans au 1er jour du camp<br><br></div>\n\n    Qualifications requises (à minima):\n    <ul>\n      <li>1 directeur du scoutisme français (DSF)</li>\n          <div *ngIf=\"(nbjeunes<13)&&(trancheage<4)\">\n            <li>1 animateur du Scoutisme français</li>\n          </div>\n\n          <div *ngIf=\"(nbjeunes>12)&&(nbjeunes<25)&&(trancheage<4)\">\n            <li>1 animateur du Scoutisme français</li>\n            <li>1 stagiaire du scoutisme français</li>\n          </div>\n\n          <div *ngIf=\"(nbjeunes>24)&&(nbjeunes<37)&&(trancheage<4)\">\n            <li>2 animateur du Scoutisme français</li>\n            <li>1 non-formé (ou stagiaire)</li>\n          </div>\n\n          <div *ngIf=\"(nbjeunes>36)&&(nbjeunes<49)&&(trancheage<4)\">\n\n            <li>2 animateur du Scoutisme français</li>\n            <li>1 stagiaire</li>\n            <li>1 non-formé</li>\n          </div>\n\n          <div *ngIf=\"(nbjeunes>12)&&(nbjeunes<25)&&(trancheage==4)\">\n          <li>1 stagiaire du scoutisme français</li>\n          </div>\n\n          <div *ngIf=\"(nbjeunes>24)&&(nbjeunes<37)&&(trancheage==4)\">\n            <li>1 animateur du Scoutisme français</li>\n            <li>1 non-formé (ou stagiaire)</li>\n          </div>\n\n          <div *ngIf=\"(nbjeunes>36)&&(nbjeunes<49)&&(trancheage==4)\">\n            <li>1 animateur du Scoutisme français</li>\n            <li>1 stagiaire</li>\n            <li>1 non-formé</li>\n          </div>\n\n\n\n          </ul>\n          <br>\n          <i><small>Réglementairement: si le nombre d’animateurs va au-delà de l’effectif minimal requis (1 animateur pour 12), les\n            obligations de qualification ne sont pas obligatoires pour les personnes supplémentaires.</small> <br><br>\n\n            Rappel: L'article 35 du règlement intérieur de l'association spécifie: \"L'unite [...] compte au maximum une trentaine de jeunes\"\n          </i>\n\n\n\n    </div>\n      <br>      <br>\n    </ion-item>\n\n\n</ion-list>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/qualification/qualification-routing.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/qualification/qualification-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: QualificationPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QualificationPageRoutingModule", function() { return QualificationPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _qualification_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./qualification.page */ "./src/app/qualification/qualification.page.ts");




var routes = [
    {
        path: '',
        component: _qualification_page__WEBPACK_IMPORTED_MODULE_3__["QualificationPage"]
    }
];
var QualificationPageRoutingModule = /** @class */ (function () {
    function QualificationPageRoutingModule() {
    }
    QualificationPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], QualificationPageRoutingModule);
    return QualificationPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/qualification/qualification.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/qualification/qualification.module.ts ***!
  \*******************************************************/
/*! exports provided: QualificationPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QualificationPageModule", function() { return QualificationPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _qualification_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./qualification-routing.module */ "./src/app/qualification/qualification-routing.module.ts");
/* harmony import */ var _qualification_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./qualification.page */ "./src/app/qualification/qualification.page.ts");







var QualificationPageModule = /** @class */ (function () {
    function QualificationPageModule() {
    }
    QualificationPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _qualification_routing_module__WEBPACK_IMPORTED_MODULE_5__["QualificationPageRoutingModule"]
            ],
            declarations: [_qualification_page__WEBPACK_IMPORTED_MODULE_6__["QualificationPage"]]
        })
    ], QualificationPageModule);
    return QualificationPageModule;
}());



/***/ }),

/***/ "./src/app/qualification/qualification.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/qualification/qualification.page.scss ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3F1YWxpZmljYXRpb24vcXVhbGlmaWNhdGlvbi5wYWdlLnNjc3MifQ== */"

/***/ }),

/***/ "./src/app/qualification/qualification.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/qualification/qualification.page.ts ***!
  \*****************************************************/
/*! exports provided: QualificationPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QualificationPage", function() { return QualificationPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var QualificationPage = /** @class */ (function () {
    function QualificationPage() {
    }
    QualificationPage.prototype.ngOnInit = function () {
    };
    QualificationPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-qualification',
            template: __webpack_require__(/*! raw-loader!./qualification.page.html */ "./node_modules/raw-loader/index.js!./src/app/qualification/qualification.page.html"),
            styles: [__webpack_require__(/*! ./qualification.page.scss */ "./src/app/qualification/qualification.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], QualificationPage);
    return QualificationPage;
}());



/***/ })

}]);
//# sourceMappingURL=qualification-qualification-module-es5.js.map