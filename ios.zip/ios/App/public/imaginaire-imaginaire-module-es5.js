(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["imaginaire-imaginaire-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/methode/imaginaire/imaginaire.page.html":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/methode/imaginaire/imaginaire.page.html ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-buttons slot=\"end\">\n      <ion-back-button text=\"Retour\"   defaultHref=\"/methode\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Constuire un imaginaire</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n\n<ion-content padding>\n\n    <b><font color=\"#045FB4\" size=5>Construire un imaginaire</font><br></b>\n    <br>\n    Un imaginaire est un histoire dans laquelle on se laisse emporter. Comme toute histoire bien construite, il est composé de différents éléments\n\n      <img src=\"assets/imgs/etapes.png\" alt=\"etapes\">\n    <br>\n    <ion-list> <div  *ngFor=\"let p of data_imaginaireetape; let i = index\">\n    <ion-item color = {{coloretape[i]}} button (click)=\"etapeactive(p.name,i)\" center>\n       <ion-avatar item-start>     <img src={{p.img}}>   </ion-avatar> <ion-label class=\"marge\"> {{p.name}}</ion-label> </ion-item>\n      <ion-item *ngIf=\"itemetapeactif==p.name\" ><ion-label text-wrap><span [innerHTML]=\"p.detail\"></span></ion-label></ion-item></div>\n    </ion-list>\n    <br>\n      <b><font color=\"#045FB4\" size=5>Faire vivre un imaginaire</font><br></b><br>\n    Un imaginaire est un monde dans lequel on rentre, une histoire dans laquelle on rêve.<br>\n    Un imaginaire c’est comme une bulle dans laquelle on fait rentrer les jeunes et dont ils ne ressortent pas avant la fin de l’activité.\n    <br>  <br>\n  <ion-list>\n    <div  *ngFor=\"let p of data_imaginaireitem; let i = index\">\n    <ion-item color = {{coloritem[i]}} button (click)=\"itemactive(p.name,i)\" center>\n     <ion-avatar item-start>     <img src={{p.img}}>   </ion-avatar> <ion-label class=\"marge\"> {{p.name}}</ion-label> </ion-item>\n     <ion-item *ngIf=\"itemitemactif==p.name\" ><ion-label text-wrap><span [innerHTML]=\"p.detail\"></span></ion-label></ion-item>\n     </div>\n  </ion-list>\n\n\n  <br>\n    <ion-card-content>\n  <i>Sais-tu chanter, improviser une histoire de pirates, marcher sur les mains, imiter les cris d’animaux, dessiner sur les murs avec un morceau de charbon ?\n  </i><br>\n  <i>Alors tu auras la discipline.</i><br>\n\n  F. DELIGNY, « Graine de crapule »\n    </ion-card-content>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/methode/imaginaire/imaginaire-routing.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/methode/imaginaire/imaginaire-routing.module.ts ***!
  \*****************************************************************/
/*! exports provided: ImaginairePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImaginairePageRoutingModule", function() { return ImaginairePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _imaginaire_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./imaginaire.page */ "./src/app/methode/imaginaire/imaginaire.page.ts");




var routes = [
    {
        path: '',
        component: _imaginaire_page__WEBPACK_IMPORTED_MODULE_3__["ImaginairePage"]
    }
];
var ImaginairePageRoutingModule = /** @class */ (function () {
    function ImaginairePageRoutingModule() {
    }
    ImaginairePageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], ImaginairePageRoutingModule);
    return ImaginairePageRoutingModule;
}());



/***/ }),

/***/ "./src/app/methode/imaginaire/imaginaire.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/methode/imaginaire/imaginaire.module.ts ***!
  \*********************************************************/
/*! exports provided: ImaginairePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImaginairePageModule", function() { return ImaginairePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _imaginaire_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./imaginaire-routing.module */ "./src/app/methode/imaginaire/imaginaire-routing.module.ts");
/* harmony import */ var _imaginaire_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./imaginaire.page */ "./src/app/methode/imaginaire/imaginaire.page.ts");







var ImaginairePageModule = /** @class */ (function () {
    function ImaginairePageModule() {
    }
    ImaginairePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _imaginaire_routing_module__WEBPACK_IMPORTED_MODULE_5__["ImaginairePageRoutingModule"]
            ],
            declarations: [_imaginaire_page__WEBPACK_IMPORTED_MODULE_6__["ImaginairePage"]]
        })
    ], ImaginairePageModule);
    return ImaginairePageModule;
}());



/***/ }),

/***/ "./src/app/methode/imaginaire/imaginaire.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/methode/imaginaire/imaginaire.page.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".marge {\n  margin-left: 2em;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbWV0aG9kZS9pbWFnaW5haXJlL0M6XFxVc2Vyc1xcVVNFUlxcc2NvdXRvYm94L3NyY1xcYXBwXFxtZXRob2RlXFxpbWFnaW5haXJlXFxpbWFnaW5haXJlLnBhZ2Uuc2NzcyIsInNyYy9hcHAvbWV0aG9kZS9pbWFnaW5haXJlL2ltYWdpbmFpcmUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0EsZ0JBQUE7QUNDQSIsImZpbGUiOiJzcmMvYXBwL21ldGhvZGUvaW1hZ2luYWlyZS9pbWFnaW5haXJlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tYXJnZSB7XHJcbm1hcmdpbi1sZWZ0OiAyZW07XHJcbn1cclxuIiwiLm1hcmdlIHtcbiAgbWFyZ2luLWxlZnQ6IDJlbTtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/methode/imaginaire/imaginaire.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/methode/imaginaire/imaginaire.page.ts ***!
  \*******************************************************/
/*! exports provided: ImaginairePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImaginairePage", function() { return ImaginairePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");




var ImaginairePage = /** @class */ (function () {
    function ImaginairePage(router, http) {
        var _this = this;
        this.router = router;
        this.http = http;
        this.itemetapeactif = 'vide';
        this.itemitemactif = 'vide';
        this.coloretape = ['light', 'light', 'light', 'light'];
        this.coloritem = ['light', 'light', 'light', 'light', 'light', 'light', 'light', 'light', 'light', 'light'];
        this.http.get("assets/data/data_imaginaireetape.json", { responseType: 'json' }).subscribe(function (fileContent) { _this.data_imaginaireetape = fileContent["etapes"]; });
        this.http.get("assets/data/data_imaginaireitem.json", { responseType: 'json' }).subscribe(function (fileContent) { _this.data_imaginaireitem = fileContent["item"]; });
    }
    ImaginairePage.prototype.ngOnInit = function () {
    };
    ImaginairePage.prototype.etapeactive = function (item, i) {
        console.log(i);
        if (this.itemetapeactif == item) {
            this.itemetapeactif = 'vide';
        }
        else {
            this.itemetapeactif = item;
        }
        if (this.itemetapeactif == 'vide') {
            this.coloretape[i] = 'light';
        }
        else {
            this.coloretape[i] = 'primary';
            if (i != 0) {
                this.coloretape[0] = 'light';
            }
            if (i != 1) {
                this.coloretape[1] = 'light';
            }
            if (i != 2) {
                this.coloretape[2] = 'light';
            }
            if (i != 3) {
                this.coloretape[3] = 'light';
            }
        }
    };
    ImaginairePage.prototype.itemactive = function (item, i) {
        if (this.itemitemactif == item) {
            this.itemitemactif = 'vide';
        }
        else {
            this.itemitemactif = item;
        }
        if (this.itemitemactif == 'vide') {
            this.coloritem[i] = 'light';
        }
        else {
            this.coloritem[i] = 'primary';
        }
        if (i != 0) {
            this.coloritem[0] = 'light';
        }
        if (i != 1) {
            this.coloritem[1] = 'light';
        }
        if (i != 2) {
            this.coloritem[2] = 'light';
        }
        if (i != 3) {
            this.coloritem[3] = 'light';
        }
        if (i != 4) {
            this.coloritem[4] = 'light';
        }
        if (i != 5) {
            this.coloritem[5] = 'light';
        }
        if (i != 6) {
            this.coloritem[7] = 'light';
        }
        if (i != 7) {
            this.coloritem[8] = 'light';
        }
        if (i != 8) {
            this.coloritem[9] = 'light';
        }
    };
    ImaginairePage.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
    ]; };
    ImaginairePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-imaginaire',
            template: __webpack_require__(/*! raw-loader!./imaginaire.page.html */ "./node_modules/raw-loader/index.js!./src/app/methode/imaginaire/imaginaire.page.html"),
            styles: [__webpack_require__(/*! ./imaginaire.page.scss */ "./src/app/methode/imaginaire/imaginaire.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], ImaginairePage);
    return ImaginairePage;
}());



/***/ })

}]);
//# sourceMappingURL=imaginaire-imaginaire-module-es5.js.map