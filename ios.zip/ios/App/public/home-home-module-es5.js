(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/home/home.page.html":
/*!***************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/home/home.page.html ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button menuId=\"first\" ></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Accueil</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n\n<ion-content class=\"ion-padding\" >\n\n<div class=\"ion-text-center\">  <img src=\"assets/imgs/general/carre.png\" alt=\"carre\" WIDTH=30% class = \"image\"></div>\n\n<br>\n\n<i><b><small><font color=\"#989aa2\">Réaliser:</font></small></b></i>\n    <div class=\"ion-text-center\"><ion-button style=\"width:80%\" router-direction=\"forward\" color=\"primary\" href=\"activite\"  size=\"large\"><ion-icon name=\"folder-open\"></ion-icon>&nbsp; &nbsp; <span>A<span class=\"ion-text-lowercase\">ctivités:</span><br> <small class=\"ion-text-lowercase\">jeux, veillées...</small> </span>  </ion-button></div>\n    <div class=\"ion-text-center\"><ion-button style=\"width:80%\" router-direction=\"forward\" color=\"primary\" href=\"prepacamp\" > <ion-icon name=\"compass\"></ion-icon> &nbsp; &nbsp;  O<span class=\"ion-text-lowercase\">bjectifs pédagogiques</span>  </ion-button></div>\n\n    <br>\n    <i><b><small><font color=\"#989aa2\">Comprendre:</font></small></b></i>\n    <div class=\"ion-text-center\"><ion-button slot=\"start\"  style=\"width:80%\" router-direction=\"forward\" color=\"primary\" href=\"methode\"  large><ion-icon slot=\"start\" name=\"book\"></ion-icon> &nbsp; &nbsp;  M<span  class=\"ion-text-lowercase\">éthode</span> </ion-button></div>\n<br>\n<i><b><small><font color=\"#989aa2\">Accompagner:</font></small></b></i>\n    <div class=\"ion-text-center\" ><ion-button style=\"width:80%\" router-direction=\"forward\" color=\"primary\" href=\"preparation\" large  ><ion-icon name=\"construct\"> </ion-icon>&nbsp; &nbsp; P<span class=\"ion-text-lowercase\">réparer une activité</span> </ion-button></div>\n    <div class=\"ion-text-center\" ><ion-button style=\"width:80%\" router-direction=\"forward\" color=\"primary\"  href=\"evaluation\" large><ion-icon name=\"speedometer\"></ion-icon>&nbsp; &nbsp; E<span class=\"ion-text-lowercase\">valuer une activité</span> </ion-button></div>\n    <br>\n  <i><b><small><font color=\"#989aa2\">Autres:</font></small></b></i>\n  <div class=\"ion-text-center\"><ion-button style=\"width:80%\" router-direction=\"forward\" color=\"primary\" href=\"qualification\" > <ion-icon name=\"ribbon\"></ion-icon> &nbsp; &nbsp;  Q<span class=\"ion-text-lowercase\">ualifications </span>&nbsp;SF  </ion-button></div>\n  <!-- <div text-center><ion-button style=\"width:80%\" router-direction=\"forward\" color=\"primary\" href=\"video\" > <ion-icon name=\"film\"></ion-icon> &nbsp; &nbsp;  V<span text-lowercase>ideos </span>&nbsp;SF  </ion-button></div> -->\n\n\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/home/home.module.ts":
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./home.page */ "./src/app/home/home.page.ts");







var HomePageModule = /** @class */ (function () {
    function HomePageModule() {
    }
    HomePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                    {
                        path: '',
                        component: _home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]
                    }
                ])
            ],
            declarations: [_home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]]
        })
    ], HomePageModule);
    return HomePageModule;
}());



/***/ }),

/***/ "./src/app/home/home.page.scss":
/*!*************************************!*\
  !*** ./src/app/home/home.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-content {\n  --background: url('accueil_estompe.png');\n  --background-repeat: no-repeat;\n  --background-position: center;\n  --background-size: contain;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9DOlxcVXNlcnNcXFVTRVJcXHNjb3V0b2JveC9zcmNcXGFwcFxcaG9tZVxcaG9tZS5wYWdlLnNjc3MiLCJzcmMvYXBwL2hvbWUvaG9tZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUE7RUFDSSx3Q0FBQTtFQUNBLDhCQUFBO0VBQ0EsNkJBQUE7RUFDQSwwQkFBQTtBQ0RKIiwiZmlsZSI6InNyYy9hcHAvaG9tZS9ob21lLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxuXG5pb24tY29udGVudCB7XG4gICAgLS1iYWNrZ3JvdW5kOiB1cmwoJy4uLy4uL2Fzc2V0cy9pbWdzL2dlbmVyYWwvYWNjdWVpbF9lc3RvbXBlLnBuZycpO1xuICAgIC0tYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbiAgICAtLWJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcbiAgICAtLWJhY2tncm91bmQtc2l6ZTogY29udGFpbjtcblxufVxuXG4vL1xuLy8gYXBwLXBhZ2UtaG9tZSB7XG4vL1xuLy9cbi8vXG4vLyAuYmFja2dyb3VuZGltYWdlIHtcbi8vICAgIGlvbi1wYWRkaW5nOiAwcHg7XG4vLyAgICBpb24tYmFja2dyb3VuZC1pbWFnZTogdXJsKCcuLi8uLi9hc3NldHMvaW1ncy9nZW5lcmFsL2FjY3VlaWwucG5nJykhaW1wb3J0YW50O1xuLy8gICAgaW9uLWJhY2tncm91bmQtc2l6ZTogY292ZXI7XG4vLyAgICBpb24tYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbi8vIH1cbi8vIH1cbi8vIGlvbi1jb250ZW50IHtcbi8vICAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJy4uLy4uL2Fzc2V0cy9pbWdzL2dlbmVyYWwvYWNjdWVpbC5wbmcnKTtcbi8vICAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuLy8gICAgIGJhY2tncm91bmQtc2l6ZTogMTAwJSAxMDAlO1xuLy8gfVxuLy9cbi8vIGlvbi1zY3JvbGwge1xuLy8gICAgIGJhY2tncm91bmQtaW1hZ2U6IHVybCgnLi4vLi4vYXNzZXRzL2ltZ3MvZ2VuZXJhbC9hY2N1ZWlsLnBuZycpO1xuLy8gICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4vLyAgICAgYmFja2dyb3VuZC1zaXplOiAxMDAlIDEwMCU7XG4vLyB9XG4vL1xuLy8gaW9uLWNvbnRlbnQgaW9uLXNjcm9sbCB7XG4vLyAgICAgYmFja2dyb3VuZC1pbWFnZTogdXJsKCcuLi8uLi9hc3NldHMvaW1ncy9nZW5lcmFsL2FjY3VlaWwucG5nJyk7XG4vLyB9XG4vL1xuLy8gLmJhY2tncm91bmRpbWFnZVxuLy8ge1xuLy8gICAgIGJhY2tncm91bmQtaW1hZ2U6IHVybCgnLi4vLi4vYXNzZXRzL2ltZ3MvZ2VuZXJhbC9hY2N1ZWlsLnBuZycpO1xuLy8gICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4vLyAgICAgYmFja2dyb3VuZC1zaXplOiAxMDAlIDEwMCU7XG4vLyB9XG4iLCJpb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogdXJsKFwiLi4vLi4vYXNzZXRzL2ltZ3MvZ2VuZXJhbC9hY2N1ZWlsX2VzdG9tcGUucG5nXCIpO1xuICAtLWJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gIC0tYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xuICAtLWJhY2tncm91bmQtc2l6ZTogY29udGFpbjtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/home/home.page.ts":
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var HomePage = /** @class */ (function () {
    function HomePage() {
    }
    HomePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-home',
            template: __webpack_require__(/*! raw-loader!./home.page.html */ "./node_modules/raw-loader/index.js!./src/app/home/home.page.html"),
            styles: [__webpack_require__(/*! ./home.page.scss */ "./src/app/home/home.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], HomePage);
    return HomePage;
}());



/***/ })

}]);
//# sourceMappingURL=home-home-module-es5.js.map