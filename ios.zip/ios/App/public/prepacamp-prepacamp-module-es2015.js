(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["prepacamp-prepacamp-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/prepacamp/prepacamp.page.html":
/*!*************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/prepacamp/prepacamp.page.html ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-buttons slot=\"end\"><ion-back-button text=\"Retour\"  defaultHref=\"home\"></ion-back-button></ion-buttons>\n    <ion-title>Préparer un camp</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content padding class = \"card-background-page\">\n\n\n<small><i>Les éléments ci dessous sont issus de projets pédagogiques déjà mis en oeuvre. Ils ne sont pas exhaustifs et doivent être condidérés comme une source d'inspiration et non pas comme des attentes ou des obligations.</i></small>\n\n<br>\n<br>\n<ion-list>\n\n\n  <ion-item  color={{color_csp}} lines=\"full\" (click)=\"goitem('csp')\"  detail button > <ion-label><h2><b>Construire sa personnalité </b></h2></ion-label></ion-item>\n  <div  *ngFor=\"let p of data_prepacamp;let i = index\" class=\"marge\">\n      <div *ngIf= \"p.type=='construire_sa_perso'\"><div *ngIf= \"item=='csp'\">\n      <ion-item button (click)=\"godisplay(i, p.name, p.type,p.titre, p.extrait, p.contenu)\" detail><ion-label class=\"marge\" text-wrap>{{p.name}}</ion-label></ion-item>\n    </div></div></div>\n\n    <ion-item  color={{color_egf}} lines=\"full\" (click)=\"goitem('egf')\"  detail button > <ion-label><h2><b>Eduquer des garçons et des filles </b></h2></ion-label></ion-item>\n    <div  *ngFor=\"let p of data_prepacamp;let i = index\" class=\"marge\">\n        <div *ngIf= \"p.type=='eduquer_g_f'\"><div *ngIf= \"item=='egf'\">\n        <ion-item button (click)=\"godisplay(i, p.name, p.type,p.titre, p.extrait, p.contenu)\" detail><ion-label class=\"marge\" text-wrap>{{p.name}}</ion-label></ion-item>\n      </div></div></div>\n\n      <ion-item  color={{color_ve}} lines=\"full\" (click)=\"goitem('ve')\"  detail button > <ion-label><h2><b>Vivre Ensemble </b></h2></ion-label></ion-item>\n      <div  *ngFor=\"let p of data_prepacamp;let i = index\" class=\"marge\">\n          <div *ngIf= \"p.type=='vivre_ensemble'\"><div *ngIf= \"item=='ve'\">\n          <ion-item button (click)=\"godisplay(i, p.name, p.type,p.titre, p.extrait, p.contenu)\" detail><ion-label class=\"marge\" text-wrap>{{p.name}}</ion-label></ion-item>\n        </div>\n      </div></div>\n\n\n    <ion-item  color={{color_halp}} (click)=\"goitem('halp')\" lines=\"full\" detail button > <ion-label><h2><b>Habiter Autrement La Planète </b></h2></ion-label></ion-item>\n    <div  *ngFor=\"let p of data_prepacamp;let i = index\" class=\"marge\">\n        <div *ngIf= \"p.type=='HALP'\"><div *ngIf= \"item=='halp'\">\n        <ion-item button (click)=\"godisplay(i, p.name, p.type,p.titre, p.extrait, p.contenu)\" detail><ion-label class=\"marge\" text-wrap>{{p.name}}</ion-label></ion-item>\n      </div></div></div>\n<br>\n\n\n\n\n\n</ion-list>\n<br><br><div text-center ><ion-button shape=\"round\" color=\"secondary\" style=\"width:80%\" href=\"https://www.sgdf.fr/le-mouvement/un-projet-educatif\">Le projet éducatif des<br>Scouts et Guides de France</ion-button></div>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/prepacamp/prepacamp-routing.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/prepacamp/prepacamp-routing.module.ts ***!
  \*******************************************************/
/*! exports provided: PrepacampPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PrepacampPageRoutingModule", function() { return PrepacampPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _prepacamp_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./prepacamp.page */ "./src/app/prepacamp/prepacamp.page.ts");




const routes = [
    {
        path: '',
        component: _prepacamp_page__WEBPACK_IMPORTED_MODULE_3__["PrepacampPage"]
    },
    {
        path: 'prepacampdisplay',
        loadChildren: () => __webpack_require__.e(/*! import() | prepacampdisplay-prepacampdisplay-module */ "prepacampdisplay-prepacampdisplay-module").then(__webpack_require__.bind(null, /*! ./prepacampdisplay/prepacampdisplay.module */ "./src/app/prepacamp/prepacampdisplay/prepacampdisplay.module.ts")).then(m => m.PrepacampdisplayPageModule)
    }
];
let PrepacampPageRoutingModule = class PrepacampPageRoutingModule {
};
PrepacampPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], PrepacampPageRoutingModule);



/***/ }),

/***/ "./src/app/prepacamp/prepacamp.module.ts":
/*!***********************************************!*\
  !*** ./src/app/prepacamp/prepacamp.module.ts ***!
  \***********************************************/
/*! exports provided: PrepacampPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PrepacampPageModule", function() { return PrepacampPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _prepacamp_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./prepacamp-routing.module */ "./src/app/prepacamp/prepacamp-routing.module.ts");
/* harmony import */ var _prepacamp_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./prepacamp.page */ "./src/app/prepacamp/prepacamp.page.ts");







let PrepacampPageModule = class PrepacampPageModule {
};
PrepacampPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _prepacamp_routing_module__WEBPACK_IMPORTED_MODULE_5__["PrepacampPageRoutingModule"]
        ],
        declarations: [_prepacamp_page__WEBPACK_IMPORTED_MODULE_6__["PrepacampPage"]]
    })
], PrepacampPageModule);



/***/ }),

/***/ "./src/app/prepacamp/prepacamp.page.scss":
/*!***********************************************!*\
  !*** ./src/app/prepacamp/prepacamp.page.scss ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3ByZXBhY2FtcC9wcmVwYWNhbXAucGFnZS5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/prepacamp/prepacamp.page.ts":
/*!*********************************************!*\
  !*** ./src/app/prepacamp/prepacamp.page.ts ***!
  \*********************************************/
/*! exports provided: PrepacampPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PrepacampPage", function() { return PrepacampPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");





let PrepacampPage = class PrepacampPage {
    constructor(router, http, storage) {
        this.router = router;
        this.http = http;
        this.storage = storage;
        this.data_prepacamp = "";
        this.color_halp = "light";
        this.color_ve = "light";
        this.color_egf = "light";
        this.color_csp = "light";
        this.http.get("assets/data/data_prepacamp.json", { responseType: 'json' }).subscribe(fileContent => { this.data_prepacamp = fileContent["prepacamp"]; });
    }
    ngOnInit() {
    }
    goitem(item_change) {
        if (item_change != this.item) {
            this.item = item_change;
        }
        else {
            this.item = 'vide';
        }
        if (this.item == "halp") {
            this.color_halp = "tertiary";
        }
        else {
            this.color_halp = "light";
        }
        if (this.item == "ve") {
            this.color_ve = "tertiary";
        }
        else {
            this.color_ve = "light";
        }
        if (this.item == "egf") {
            this.color_egf = "tertiary";
        }
        else {
            this.color_egf = "light";
        }
        if (this.item == "csp") {
            this.color_csp = "tertiary";
        }
        else {
            this.color_csp = "light";
        }
    }
    godisplay(id, name, type, titre, extrait, contenu) {
        this.router.navigate(['prepacampdisplay', { id: id, name: name, type: type, titre: titre, extrait: extrait, contenu: contenu }]);
    }
};
PrepacampPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_4__["Storage"] }
];
PrepacampPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-prepacamp',
        template: __webpack_require__(/*! raw-loader!./prepacamp.page.html */ "./node_modules/raw-loader/index.js!./src/app/prepacamp/prepacamp.page.html"),
        styles: [__webpack_require__(/*! ./prepacamp.page.scss */ "./src/app/prepacamp/prepacamp.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
        _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"],
        _ionic_storage__WEBPACK_IMPORTED_MODULE_4__["Storage"]])
], PrepacampPage);



/***/ })

}]);
//# sourceMappingURL=prepacamp-prepacamp-module-es2015.js.map