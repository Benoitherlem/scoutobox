(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["preparation-preparation-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/preparation/preparation.page.html":
/*!*****************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/preparation/preparation.page.html ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-buttons slot=\"end\">\n      <ion-back-button text=\"Retour\"  defaultHref=\"home\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Preparation</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n\n  <ion-card class=\"card-background-page\" >\n    <img src= \"assets/imgs/creiras/creira_flat.png\"/>\n    <div class=\"card-title\"> {{item}}</div>\n   </ion-card>\n\n\n\n<div class=\"marge\" *ngIf=\"item == 'RESULTAT'\"> <b><br>Points restant à instruire:</b><br><br></div>\n   <ion-list>\n     <div *ngFor=\"let p of data; let i = index\">\n       <div *ngIf= \"p.categorie == item\" >\n  <ion-item text-wrap>\n    <ion-label text-wrap>{{p.check}}</ion-label> <ion-checkbox item-end color={{p.check_color}}  [(ngModel)]=prepa_coche[i*3]  ></ion-checkbox>  </ion-item>\n    <div *ngIf=\"prepa_coche[i*3]==true\"><ion-item *ngIf=\"p.souscheck1\" ><ion-label text-wrap class=\"marge\"><h4><ion-icon name=\"arrow-forward\"></ion-icon>&nbsp;&nbsp;<span [innerHTML]= \"p.souscheck1\" ></span></h4></ion-label> <ion-checkbox item-end color={{p.souscheck1_color}} [(ngModel)]=prepa_coche[i*3+1] ></ion-checkbox></ion-item></div>\n    <div *ngIf=\"prepa_coche[i*3]==true\"><ion-item *ngIf=\"p.souscheck2\" ><ion-label text-wrap class=\"marge\"><h4><ion-icon name=\"arrow-forward\"></ion-icon>&nbsp;&nbsp;<span [innerHTML]= \"p.souscheck2\" ></span></h4></ion-label> <ion-checkbox item-end color={{p.souscheck2_color}} [(ngModel)]=prepa_coche[i*3+2]  ></ion-checkbox></ion-item></div>\n\n\n    </div>\n\n    <div  class=\"marge\" *ngIf=\"item == 'RESULTAT' && prepa_coche[i*3]!=true && p.check_color!='danger'\"> <small>[{{p.categorie}}]-{{p.check}}</small> </div>\n    <div   class=\"marge\" *ngIf=\"item == 'RESULTAT' && prepa_coche[i*3+1]!=true && prepa_coche[i*3]==true && p.souscheck1_color!='danger'\"><span *ngIf=\"p.souscheck1\"> -&nbsp;<small>{{p.souscheck1}} </small></span></div>\n    <div   class=\"marge\" *ngIf=\"item == 'RESULTAT' && prepa_coche[i*3+2]!=true && prepa_coche[i*3]==true && p.souscheck2_color!='danger'\"><span *ngIf=\"p.souscheck2\"> -&nbsp;<small>{{p.souscheck2}}</small> </span></div>\n\n\n\n  </div>\n   </ion-list>\n\n\n\n\n   <div text-center *ngIf= \"item == 'CADRE'\">\n     <ion-button  (click)=\"raz_alerte(prepa_coche)\" > Effacer tout</ion-button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n     <ion-button round (click)=\"openPreparationPage(regles, prepa_coche)\" > Règles &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <ion-icon name=\"arrow-forward\"></ion-icon> </ion-button>\n  </div>\n\n   <div text-center *ngIf= \"item == 'REGLES'\">\n     <ion-button round (click)=\"openPreparationPageback(cadre, prepa_coche)\" ><ion-icon name=\"arrow-back\"></ion-icon>&nbsp;&nbsp;Cadre  </ion-button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n     <ion-button round (click)=\"openPreparationPage(equipe, prepa_coche)\" >Equipe &nbsp;&nbsp; <ion-icon name=\"arrow-forward\"></ion-icon> </ion-button>\n   </div>\n   <div text-center *ngIf= \"item == 'EQUIPE'\">\n     <ion-button round (click)=\"openPreparationPageback(regles, prepa_coche)\" ><ion-icon name=\"arrow-back\"></ion-icon>&nbsp;&nbsp;Règles  </ion-button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n     <ion-button round (click)=\"openPreparationPage(imaginaire, prepa_coche)\" >Imaginaire &nbsp;&nbsp; <ion-icon name=\"arrow-forward\"></ion-icon> </ion-button>\n   </div>\n   <div text-center *ngIf= \"item == 'IMAGINAIRE'\">\n     <ion-button round (click)=\"openPreparationPageback(equipe, prepa_coche)\" ><ion-icon name=\"arrow-back\"></ion-icon>&nbsp;&nbsp;Equipe  </ion-button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n     <ion-button round (click)=\"openPreparationPage(roles, prepa_coche)\" >Roles &nbsp;&nbsp; <ion-icon name=\"arrow-forward\"></ion-icon> </ion-button>\n   </div>\n   <div text-center *ngIf= \"item == 'ROLES'\">\n     <ion-button round (click)=\"openPreparationPageback(imaginaire, prepa_coche)\" ><ion-icon name=\"arrow-back\"></ion-icon>&nbsp;&nbsp;Imaginaire  </ion-button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n     <ion-button round (click)=\"openPreparationPage(action, prepa_coche)\" >Action &nbsp;&nbsp; <ion-icon name=\"arrow-forward\"></ion-icon> </ion-button>\n   </div>\n   <div text-center *ngIf= \"item == 'ACTION'\">\n     <ion-button round (click)=\"openPreparationPageback(roles, prepa_coche)\" ><ion-icon name=\"arrow-back\"></ion-icon>&nbsp;&nbsp;Roles  </ion-button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n     <ion-button round (click)=\"openPreparationPage(sens, prepa_coche)\" >Sens &nbsp;&nbsp; <ion-icon name=\"arrow-forward\"></ion-icon> </ion-button>\n   </div>\n   <div text-center *ngIf= \"item == 'SENS'\">\n     <ion-button round (click)=\"openPreparationPageback(action, prepa_coche)\" ><ion-icon name=\"arrow-back\"></ion-icon>&nbsp;&nbsp;Action  </ion-button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n     <ion-button color =\"secondary\" (click)=\"openPreparationPage(resultat, prepa_coche)\" >Bilan &nbsp;&nbsp; <ion-icon name=\"arrow-forward\"></ion-icon> </ion-button>\n  </div>\n\n   <div text-center *ngIf= \"item == 'RESULTAT'\">\n     <ion-button round (click)=\"openPreparationPageback(sens, prepa_coche)\"><ion-icon name=\"arrow-back\"></ion-icon>&nbsp;&nbsp; Sens</ion-button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n     <ion-button  (click)=\"raz_alerte (prepa_coche)\" > Effacer tout </ion-button>\n   </div>\n\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/preparation/preparation-routing.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/preparation/preparation-routing.module.ts ***!
  \***********************************************************/
/*! exports provided: PreparationPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PreparationPageRoutingModule", function() { return PreparationPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _preparation_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./preparation.page */ "./src/app/preparation/preparation.page.ts");




var routes = [
    {
        path: '',
        component: _preparation_page__WEBPACK_IMPORTED_MODULE_3__["PreparationPage"]
    }
];
var PreparationPageRoutingModule = /** @class */ (function () {
    function PreparationPageRoutingModule() {
    }
    PreparationPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        })
    ], PreparationPageRoutingModule);
    return PreparationPageRoutingModule;
}());



/***/ }),

/***/ "./src/app/preparation/preparation.module.ts":
/*!***************************************************!*\
  !*** ./src/app/preparation/preparation.module.ts ***!
  \***************************************************/
/*! exports provided: PreparationPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PreparationPageModule", function() { return PreparationPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _preparation_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./preparation-routing.module */ "./src/app/preparation/preparation-routing.module.ts");
/* harmony import */ var _preparation_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./preparation.page */ "./src/app/preparation/preparation.page.ts");







var PreparationPageModule = /** @class */ (function () {
    function PreparationPageModule() {
    }
    PreparationPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _preparation_routing_module__WEBPACK_IMPORTED_MODULE_5__["PreparationPageRoutingModule"]
            ],
            declarations: [_preparation_page__WEBPACK_IMPORTED_MODULE_6__["PreparationPage"]]
        })
    ], PreparationPageModule);
    return PreparationPageModule;
}());



/***/ }),

/***/ "./src/app/preparation/preparation.page.scss":
/*!***************************************************!*\
  !*** ./src/app/preparation/preparation.page.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".card-background-page ion-card {\n  position: relative;\n}\n.card-background-page .card-title {\n  position: absolute;\n  top: 30%;\n  font-size: 2em;\n  width: 100%;\n  font-weight: bold;\n  color: #fff;\n  text-align: center;\n}\n.card-background-page .card-subtitle {\n  font-size: 1em;\n  position: absolute;\n  top: 10%;\n  width: 100%;\n  color: #000;\n  text-align: center;\n}\n.card-background-page .marge {\n  margin-left: 2em;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHJlcGFyYXRpb24vQzpcXFVzZXJzXFxVU0VSXFxzY291dG9ib3gvc3JjXFxhcHBcXHByZXBhcmF0aW9uXFxwcmVwYXJhdGlvbi5wYWdlLnNjc3MiLCJzcmMvYXBwL3ByZXBhcmF0aW9uL3ByZXBhcmF0aW9uLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFRTtFQUNFLGtCQUFBO0FDREo7QURNRTtFQUNFLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLGNBQUE7RUFDQSxXQUFBO0VBQ0EsaUJBQUE7RUFDQSxXQUFBO0VBQ0Usa0JBQUE7QUNKTjtBRE9FO0VBRUUsY0FBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7QUNOSjtBRFNFO0VBQ0EsZ0JBQUE7QUNQRiIsImZpbGUiOiJzcmMvYXBwL3ByZXBhcmF0aW9uL3ByZXBhcmF0aW9uLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jYXJkLWJhY2tncm91bmQtcGFnZSB7XHJcblxyXG4gIGlvbi1jYXJkIHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAvLyAgdGV4dC1hbGlnbjogbGVmdDtcclxuXHJcbiAgfVxyXG5cclxuICAuY2FyZC10aXRsZSB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDMwJTtcclxuICAgIGZvbnQtc2l6ZTogMi4wZW07XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICB9XHJcblxyXG4gIC5jYXJkLXN1YnRpdGxlIHtcclxuXHJcbiAgICBmb250LXNpemU6IDEuMGVtO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiAxMCU7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGNvbG9yOiAjMDAwO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIH1cclxuXHJcbiAgLm1hcmdlIHtcclxuICBtYXJnaW4tbGVmdDogMmVtO1xyXG4gIH1cclxuXHJcblxyXG59XHJcbiIsIi5jYXJkLWJhY2tncm91bmQtcGFnZSBpb24tY2FyZCB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cbi5jYXJkLWJhY2tncm91bmQtcGFnZSAuY2FyZC10aXRsZSB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiAzMCU7XG4gIGZvbnQtc2l6ZTogMmVtO1xuICB3aWR0aDogMTAwJTtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGNvbG9yOiAjZmZmO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG4uY2FyZC1iYWNrZ3JvdW5kLXBhZ2UgLmNhcmQtc3VidGl0bGUge1xuICBmb250LXNpemU6IDFlbTtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDEwJTtcbiAgd2lkdGg6IDEwMCU7XG4gIGNvbG9yOiAjMDAwO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG4uY2FyZC1iYWNrZ3JvdW5kLXBhZ2UgLm1hcmdlIHtcbiAgbWFyZ2luLWxlZnQ6IDJlbTtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/preparation/preparation.page.ts":
/*!*************************************************!*\
  !*** ./src/app/preparation/preparation.page.ts ***!
  \*************************************************/
/*! exports provided: PreparationPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PreparationPage", function() { return PreparationPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");







var PreparationPage = /** @class */ (function () {
    function PreparationPage(router, http, storage, navCtrl, alertController) {
        var _this = this;
        this.router = router;
        this.http = http;
        this.storage = storage;
        this.navCtrl = navCtrl;
        this.alertController = alertController;
        this.data = "";
        this.filecontent = "";
        this.prepa_coche = [];
        this.item = "";
        this.cadre = "";
        this.regles = "";
        this.imaginaire = "";
        this.equipe = "";
        this.roles = "";
        this.action = "";
        this.sens = "";
        this.resultat = "";
        this.vide = [];
        this.cadre = "CADRE";
        this.regles = "REGLES";
        this.imaginaire = "IMAGINAIRE";
        this.equipe = "EQUIPE";
        this.roles = "ROLES";
        this.action = "ACTION";
        this.sens = "SENS";
        this.resultat = "RESULTAT";
        this.storage.get('prepa_item').then(function (val) { _this.item = val; });
        this.storage.get('prepa_coche').then(function (val) { _this.prepa_coche = val; });
        this.http.get("assets/data/data_preparation.json", { responseType: 'json' }).subscribe(function (fileContent) { _this.data = fileContent["preparation"]; });
    }
    PreparationPage.prototype.ngOnInit = function () {
    };
    PreparationPage.prototype.openPreparationPageback = function (item, coche_prepa) {
        this.item = item;
        this.router.navigate(['/preparation']);
    };
    PreparationPage.prototype.openPreparationPage = function (item, prepa_coche) {
        this.item = item;
        //this.storage.set('prepa_item', 'EQUIPE' );
        //this.storage.get('prepa_item').then((val) => {console.log(val);item = val});
        //console.log("ok");
        this.router.navigate(['/preparation']);
        //
        //  this.storage.set('prepa_coche', prepa_coche);
        //  this.storage.get('prepa_item').then((val) => {console.log(val);this.item = val});
        //  this.router.navigate(['/preparation']);
    };
    //openPreparationPageback(item, coche_prepa) {   this.navCtrl.push(PreparationPage,{item:item, coche_prepa:coche_prepa}, {animate:true, animation: "transition",direction: 'back'});   }
    PreparationPage.prototype.raz_alerte = function (prepa_coche) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var raz_coche, alert;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        raz_coche = [];
                        return [4 /*yield*/, this.alertController.create({
                                header: 'Effacer tout!',
                                message: 'Souhaitez vous effacer la check-list ?',
                                buttons: [
                                    {
                                        text: 'Cancel',
                                        role: 'cancel',
                                        cssClass: 'secondary',
                                        handler: function () {
                                            ;
                                        }
                                    }, {
                                        text: 'Effacer',
                                        handler: function () {
                                            _this.prepa_coche = raz_coche;
                                            _this.storage.set('prepa_coche', raz_coche);
                                            _this.item = 'CADRE';
                                            _this.router.navigate(['/preparation']);
                                        }
                                    }
                                ]
                            })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        ;
                        return [2 /*return*/];
                }
            });
        });
    };
    PreparationPage.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] },
        { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] }
    ]; };
    PreparationPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-preparation',
            template: __webpack_require__(/*! raw-loader!./preparation.page.html */ "./node_modules/raw-loader/index.js!./src/app/preparation/preparation.page.html"),
            styles: [__webpack_require__(/*! ./preparation.page.scss */ "./src/app/preparation/preparation.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"],
            _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]])
    ], PreparationPage);
    return PreparationPage;
}());



/***/ })

}]);
//# sourceMappingURL=preparation-preparation-module-es5.js.map